exports.paginaInicial = (req, res) => {
  res.send('Obrigado por entrar em contato.');
};
