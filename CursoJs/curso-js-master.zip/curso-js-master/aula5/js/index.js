// Um comentário
console.log('Olá mundo!');
console.log('Este trecho será exibido no console do navegador.');
alert('Olá mundo!');
