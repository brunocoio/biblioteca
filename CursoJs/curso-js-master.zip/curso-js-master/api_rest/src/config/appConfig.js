export default {
  url: process.env.APP_URL,
};
